-- Import this in phpMyAdmin to store the special Taktjing card in Cloud MySQL.

START TRANSACTION;

INSERT INTO categories (id, name, description)
VALUES
  (6, 'Ultra Secret Rare', 'Ultra rare custom showcase cards')
ON DUPLICATE KEY UPDATE
  name = VALUES(name),
  description = VALUES(description);

INSERT INTO products
  (id, category_id, name, description, price, stock, location_count, image_url, is_active)
VALUES
  (
    999,
    6,
    'Taktjing VMAX Gold Secret Rare',
    'Ultra secret custom TCG showcase card.',
    9999.00,
    1,
    1,
    'special-taktjing-vmax-front',
    1
  )
ON DUPLICATE KEY UPDATE
  category_id = VALUES(category_id),
  name = VALUES(name),
  description = VALUES(description),
  price = VALUES(price),
  stock = VALUES(stock),
  location_count = VALUES(location_count),
  image_url = VALUES(image_url),
  is_active = VALUES(is_active);

COMMIT;
